ESX = exports['es_extended']:getSharedObject()

RegisterCommand('givecar', function(source, args, rawCommand)
    local xPlayer = ESX.GetPlayerFromId(source)

    if not xPlayer then return end

    if xPlayer.getGroup() ~= 'admin' and xPlayer.getGroup() ~= 'superadmin' then
        xPlayer.showNotification('~r~You do not have permission to use this command.')
        return
    end

    local targetId = tonumber(args[1])
    local vehicleModel = args[2]

    if not targetId or not vehicleModel then

        xPlayer.showNotification('~r~Usage: /givecar [id] [spawncode]')
        return
    end

    local targetPlayer = ESX.GetPlayerFromId(targetId)
    if not targetPlayer then
        xPlayer.showNotification('~r~Player not online.')
        return
    end

    local identifier = targetPlayer.identifier
    local plate = string.upper("ADM"..math.random(1000, 9999))

    local vehicleProps = json.encode({
        model = joaat(vehicleModel),
        plate = plate
    })

    MySQL.Async.execute('INSERT INTO owned_vehicles (owner, plate, vehicle, type, stored) VALUES (@owner, @plate, @vehicle, @type, @stored)', {
        ['@owner']   = identifier,
        ['@plate']   = plate,
        ['@vehicle'] = vehicleProps,
        ['@type']    = 'car',
        ['@stored']  = 1
    }, function(rowsChanged)
        if rowsChanged > 0 then
            xPlayer.showNotification('~g~Vehicle given successfully to '..GetPlayerName(targetId))
            targetPlayer.showNotification('~b~You have been given a '..vehicleModel..' with plate '..plate)
        else
            xPlayer.showNotification('~r~Failed to give vehicle.')
        end
    end)
end, false)

function joaat(key)
    return GetHashKey(key)
end
