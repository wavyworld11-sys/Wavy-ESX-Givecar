# Script by wavy

This resource is licensed under the **Wavy Proprietary License**.  
Do not redistribute without permission.

🚗 ESX GiveCar Command (by wavy)

📂 Installation
1. Put the `wavy_givecar` folder into your server’s `resources` folder.
2. Add this to your server.cfg:
   ensure wavy_givecar
3. Make sure your database has the ESX default `owned_vehicles` table.

🔑 Permissions
- Only `admin` and `superadmin` can use the command.

📝 Usage
/givecar [id] [spawncode]

Example:
/givecar 5 sultan
➡ Gives player with ID 5 a Sultan, stored permanently in their garage.

