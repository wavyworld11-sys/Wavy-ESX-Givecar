ESX = exports['es_extended']:getSharedObject()

AddEventHandler('onClientResourceStart', function(resName)
    if GetCurrentResourceName() ~= resName then return end

    TriggerEvent('chat:addSuggestion', '/givecar', 'Give a vehicle to a player',
        {
            { name = "id", help = "Server ID of the player" },
            { name = "spawncode", help = "Vehicle spawn name (e.g. sultan)" }
        }
    )
end)
