fx_version 'cerulean'
game 'gta5'

lua54 'yes'

author 'wavy'
description 'GiveCar'
version '1.0.0'

server_scripts {
    '@mysql-async/lib/MySQL.lua',
    '@es_extended/imports.lua',
    'server.lua'
}

client_scripts {
    'client.lua'
}
